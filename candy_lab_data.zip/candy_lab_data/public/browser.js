document.addEventListener("click", function (e) {
  // Delete Item
  if (e.target.classList.contains("delete-me")) {
    if (confirm("Are you sure you want to delete this item?")) {
      axios.post("/delete-item", { id: e.target.getAttribute("data-id") }).then(function () {
        e.target.parentElement.parentElement.remove();
      }).catch(function () {
        console.log("Please try again later.");
      });
    }
  }

  // Edit Item
  if (e.target.classList.contains("edit-me")) {
    var userInput = prompt("Enter new candy name", e.target.parentElement.parentElement.querySelector(".item-text").innerHTML);
    if (userInput) {
      axios.post("/update-item", { text: userInput, id: e.target.getAttribute("data-id") }).then(function () {
        e.target.parentElement.parentElement.querySelector(".item-text").innerHTML = userInput;
      }).catch(function () {
        console.log("Please try again later.");
      });
    }
  }
});

//Creating item when submitted

document.getElementById("create-form").addEventListener("submit", function (e) {
  e.preventDefault();
  var candyShape = document.getElementById("candyShape-field").value;
  var candyColor = document.getElementById("candyColor-field").value;
  var candySweetness = document.getElementById("candySweetness-field").value;
  var candyHardness = document.getElementById("candyHardness-field").value;
  var textElement = document.getElementById("create-field");
  var timestamp = new Date().toLocaleString();

  axios.post("/create-item", {
    text: textElement.value,
    candyShape: candyShape,
    candyColor: candyColor,
    candySweetness: candySweetness,
    candyHardness: candyHardness,
    timestamp: timestamp,
  }).then(function (response) {
    var listItem = document.createElement("li");
    listItem.setAttribute("class", "list-group-item list-group-item-action d-flex align-items-center justify-content-between");
    listItem.innerHTML = `<span class="item-text">${textElement.value}</span>
      <span class="item-candy">
        Shape: ${candyShape} | Color: ${candyColor} | Sweetness: ${candySweetness} | Hardness: ${candyHardness}
        <br>
        Time Created: ${timestamp}
        <br>
        Item ID: ${response.data._id}
      </span>
      <div>
        <button data-id="${response.data._id}" class="edit-me btn btn-secondary btn-sm mr-1">Edit</button>
        <button data-id="${response.data._id}" class="delete-me btn btn-danger btn-sm">Delete</button>
      </div>`;

    document.getElementById("item-list").prepend(listItem);
    textElement.value = "";
    textElement.focus();
  }).catch(function () {
    console.log("Please try again later.");
  });
});