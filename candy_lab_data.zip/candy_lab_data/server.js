const express = require("express");
const { MongoClient, ObjectId } = require("mongodb");

const app = express();
let db;

app.use(express.static("public"));

//mongodb connection string and starting the server

async function go() {
  const client = new MongoClient("mongodb+srv://new:kleopatra1453@cluster0.n2ir9uh.mongodb.net/TodoApp?retryWrites=true&w=majority");
  await client.connect();
  db = client.db();
  app.listen(3000);
}

go();

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

//generating item template

function itemTemplate(item) {
  let shapeClass = "";
  let colorClass = "";
  let sweetnessClass = "";
  let hardnessClass = "";
  let result = "";

  if (item.candyShape === "Broken") {
    shapeClass = "red";
    result = "This candy will be tested again";
  }

  if (item.candyColor === "Dark") {
    colorClass = "red";
    result = "This candy will be tested again";
  }

  if (item.candySweetness === "100%") {
    sweetnessClass = "red";
    result = "This candy will be tested again";
  }

  if (item.candyHardness === "Soft") {
    hardnessClass = "red";
    result = "This candy will be tested again";
  }

  return `<li class="list-group-item list-group-item-action d-flex align-items-center justify-content-between">
    <span class="item-text">${item.text}</span>
    <span class="item-candy">
      Shape: <span class="${shapeClass}">${item.candyShape}</span> | Color: <span class="${colorClass}">${item.candyColor}</span> | Sweetness: <span class="${sweetnessClass}">${item.candySweetness}</span> | Hardness: <span class="${hardnessClass}">${item.candyHardness}</span>
      <br>
      ${result ? `Result: ${result}` : ""}
      <br>
      ${item.timestamp ? `Time Created: ${item.timestamp}` : ""}
      <br>
      Item ID: ${item._id}
    </span>
    <div>
      <button data-id="${item._id}" class="edit-me btn btn-secondary btn-sm mr-1">Edit</button>
      <button data-id="${item._id}" class="delete-me btn btn-danger btn-sm">Delete</button>
    </div>
  </li>`;
}

//homepage route
app.get("/", async function (req, res) {
  const items = await db.collection("items").find().toArray();
  const itemsHtml = items
    .map(function (item) {
      return itemTemplate(item);
    })
    .join("");

  const html = `<!DOCTYPE html>
  <html>
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Laboratory Data</title>
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
      <style>
        .red {
          color: red;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <h1 class="display-4 text-center py-1">Lab. Input Sheet</h1>
        <div class="jumbotron p-3 shadow-sm">
          <form id="create-form" action="/create-item" method="POST">
            <div class="d-flex align-items-center">
              <input id="create-field" name="text" autofocus autocomplete="off" class="form-control mr-3" type="text" placeholder="Candy Name">
              <select id="candyShape-field" name="candyShape" class="form-control mr-2">
                <option value="">Select Shape</option>
                <option value="Round">Round</option>
                <option value="Rectangular">Rectangular</option>
                <option value="Broken">Broken</option>
              </select>
              <select id="candyColor-field" name="candyColor" class="form-control mr-2">
                <option value="">Select Color</option>
                <option value="Dark">Dark</option>
                <option value="Medium">Medium</option>
                <option value="Light">Light</option>
              </select>
              <select id="candySweetness-field" name="candySweetness" class="form-control mr-2">
                <option value="">Select Sweetness</option>
                <option value="100%">100%</option>
                <option value="50%">50%</option>
                <option value="20%">20%</option>
              </select>
              <select id="candyHardness-field" name="candyHardness" class="form-control mr-2">
                <option value="">Select Hardness</option>
                <option value="Hard">Hard</option>
                <option value="Soft">Soft</option>
              </select>
              <input name="timestamp" type="hidden">
              <button class="btn btn-primary">Add New Item</button>
            </div>
          </form>
        </div>
        <ul id="item-list" class="list-group pb-5">
          ${itemsHtml}
        </ul>
      </div>
      <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
      <script src="/browser.js"></script>
    </body>
  </html>`;

  res.send(html);
});

//creating new item to database
app.post("/create-item", async function (req, res) {
  const info = await db.collection("items").insertOne({
    text: req.body.text,
    candyShape: req.body.candyShape,
    candyColor: req.body.candyColor,
    candySweetness: req.body.candySweetness,
    candyHardness: req.body.candyHardness,
    timestamp: req.body.timestamp,
  });
  const item = {
    _id: info.insertedId,
    text: req.body.text,
    candyShape: req.body.candyShape,
    candyColor: req.body.candyColor,
    candySweetness: req.body.candySweetness,
    candyHardness: req.body.candyHardness,
    timestamp: req.body.timestamp,
  };
  res.json(item);
});

//updating to database
app.post("/update-item", async function (req, res) {
  await db
    .collection("items")
    .findOneAndUpdate(
      { _id: new ObjectId(req.body.id) },
      { $set: { text: req.body.text } }
    );
  res.send("Success");
});

//deleting from database
app.post("/delete-item", async function (req, res) {
  await db
    .collection("items")
    .deleteOne({ _id: new ObjectId(req.body.id) });
  res.send("Success");
});


//to start npm run watch